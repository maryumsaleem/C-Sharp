﻿using FirstApp;


Console.WriteLine(Product.Counter);


Product p1=new Product();
p1.Id = 1;
p1.Name = "Aaa";
p1.CostPrice = 100;

Product p2 = new Product(2, "Bbb", 200);


Product p3 = new Product { Name="Ccc", CostPrice=300 };

Product p4 = new Product(p3);



Console.WriteLine(Product.Counter);



//Country pk=new Country();
//pk.Id = 1;
//pk.Name = "Pakistan";
//pk.Code = 92;
//Console.WriteLine(pk.Summary);













Console.ReadKey();

