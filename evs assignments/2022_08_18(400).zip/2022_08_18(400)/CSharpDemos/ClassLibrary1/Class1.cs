﻿namespace ClassLibrary1
{
    public class Class1
    {
        internal int x;
    }


}